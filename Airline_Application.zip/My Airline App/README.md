# Introduction
<p>The "Android-Flight-Reservation-App" is a basic android project developed for Android Mobile Development Course. It implements MVC pattern and uses SQLite database to store persistent data. </p>
<p>The project can be used by beginner android developers who want to learn the basics of android UI development, SQLite database, and MVC.</p>

<p align="center"><img src="https://user-images.githubusercontent.com/28815677/39102544-22945852-4673-11e8-9a45-07ee617bc7d2.png" width="250" />                <img src="https://user-images.githubusercontent.com/28815677/39102711-456cd8b2-4674-11e8-8740-a0efa343abe3.png" width="250" />                <img src="https://user-images.githubusercontent.com/28815677/39102701-37b7fa4e-4674-11e8-8505-0d0aeef65fa1.png" width="250" /></p>






